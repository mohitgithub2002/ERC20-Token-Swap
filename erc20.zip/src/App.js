import "./App.css";
import { useState, useEffect } from "react";
import connectContract, { contract } from "./connectContract";
import Swal from "sweetalert2";
import { ethers } from "ethers";


function App() {
     //const [index, setIndex] = useState("");
     const [isOwner, setIsOwner] = useState(false);
     const [userEthBalance, setUserEthBalance] = useState(0);
     const [userErc20Balance, setUserErc20Balance] = useState();
     const [account, setAccount] = useState(false);
     const [value1, setValue1] = useState('');
     const [value2, setValue2] = useState('');
     const [rate, setRate] = useState(0);
     useEffect(() => {
          if (account) {
               async function fetchBalance(account) {
                    try {
                         const provider = ethers.getDefaultProvider();
                         const balance = await provider.getBalance(account);
                         console.log("balance:", balance);
                         return balance;
                    } catch (error) {
                         console.error("Error fetching balance:", error);
                    }
                    
               }
               let fun = fetchBalance(account);
               fun.then((res) => {
                    const balString = ethers.utils.formatEther(res);
                    const balance = Number(balString);
                    const bal = balance.toFixed(2);
                    setUserEthBalance(bal);
                    console.log("eth:",bal);
                    
               });

               async function fetchErc20(account){
                    try{
                         const balance = await contract.checkERC20Balance(account);
                         return balance;
                    }
                    catch(error){
                         console.error("Error fetching balance:", error);
                    }
               }
               let fun2 = fetchErc20(account);
               //console.log("fun2:",fun2);
               fun2.then((res) => {
                    const balString = ethers.utils.formatEther(res);
                    const balance = Number(balString);
                    const bal = balance.toFixed(2);
                    setUserErc20Balance(bal);
                    console.log("erc20:",bal);
               });
               
               
    
          }
     }, [account]);

     //connect to metamask
     const { ethereum } = window;
     const connectMetamask = async () => {
          if (window.ethereum !== undefined) {
               const accounts = await ethereum.request({
                    method: "eth_requestAccounts",
               });
               setAccount(accounts[0]);
          }
     };

     //connect to contract
     connectContract();

     //swap
     async function handleSwap() {
          try {
               const etherValue = {
                    value: ethers.utils.parseEther("0.0000000001"),
               };
               const reciept = await contract.buy({ value: "100" });
               console.log("reciept : ", reciept);
               const owner = await contract.OWNER();
               const rate = await contract.RATE();
               const remainingTokens = await contract.remainingFund();
               console.log(
                    "Data : ",
                    owner,
                    ethers.utils.formatEther(rate),
                    ethers.utils.formatEther(remainingTokens)
               );
               Swal.fire({
                    icon: "success",
                    title: "Transaction Details",
                    text: `Transaction Hash : ${reciept.hash} \n`,
               });
          } catch (error) {
               Swal.fire({
                    icon: "error",
                    title: "Transaction Details",
                    text: error.reason,
               });
          }
     }

     //getting rate from contract
     async function getRate() {
          if(rate==0)
          {
               try {
               const rate = await contract.RATE();
               console.log("rate : ", rate.toNumber());
               setRate(rate.toNumber());
          } catch (error) {
               console.log("error : ", error);
          }}
     }
     getRate();

     //handle input
     function handleValue1(event){
          const newValue = event.target.value;
          setValue1(newValue);
          setValue2(newValue*rate);
     }
     function handleValue2(event){
          const newValue = event.target.value;
          setValue2(newValue);
          setValue1(newValue/rate);
     }

     
     

     return (
          <div className="App">
               <header className="nevbar">
                    <span></span>
                    <h1>Uniswap ERC20 Token swap</h1>
                    <button onClick={connectMetamask}>
                         {account
                              ? `${account.substring(
                                     0,
                                     4
                                )}....${account.substring(
                                     account.length - 4,
                                     account.length
                                )}`
                              : "Connect "}
                    </button>{" "}
               </header>

               <div className="container">
                    
                         <div className="box">
                              <h2> ERC20 Token Swap </h2>
                              <div className="minibox1">
                                   <button>ETH</button>
                                   <input
                                        type="number"
                                        value={value1}
                                        className="form-input"
                                        placeholder="0"
                                        onChange={(event) =>
                                             handleValue1(event)
                                        }
                                   />
                              </div>
                              <div className="minibox1">
                                   <button>ERC20</button>
                                   <input
                                        type="number"
                                        value={value2}
                                        className="form-input"
                                        placeholder="0"
                                        onChange={(event) =>
                                             handleValue2(event)
                                        }
                                   />
                              </div>
                              <div className="minibox3">
                                   <h4>Your Balances</h4>
                                   <div className="para">
                                        <p>{userEthBalance} ETH</p>
                                        <p>{userErc20Balance} ERC20</p>
                                   </div>
                              </div>
                              <div className="minibox4">
                                   <button onClick={handleSwap}>Swap</button>
                                   {/* <button visiblity={isOwner?'visible':'hidden'} onClick={checkFund} >RemainingFund</button> */}
                              </div>
                         </div>
                    
               </div>

          
          </div>
     );
}

export default App;
