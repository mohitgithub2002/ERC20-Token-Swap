import { ethers } from "ethers";
let contract;
const connectContract = async () => {
     const Address = "0x49C6fa7C87f58A36541B978aE0E557289fEffaB7";
     const Abi = [
          {
               "inputs": [],
               "name": "buy",
               "outputs": [
                    {
                         "internalType": "bool",
                         "name": "",
                         "type": "bool"
                    }
               ],
               "stateMutability": "payable",
               "type": "function"
          },
          {
               "inputs": [],
               "name": "retrieveToken",
               "outputs": [
                    {
                         "internalType": "bool",
                         "name": "",
                         "type": "bool"
                    }
               ],
               "stateMutability": "nonpayable",
               "type": "function"
          },
          {
               "inputs": [
                    {
                         "internalType": "address",
                         "name": "_erc20Token",
                         "type": "address"
                    }
               ],
               "stateMutability": "nonpayable",
               "type": "constructor"
          },
          {
               "inputs": [
                    {
                         "internalType": "address",
                         "name": "_user",
                         "type": "address"
                    }
               ],
               "name": "checkERC20Balance",
               "outputs": [
                    {
                         "internalType": "uint256",
                         "name": "",
                         "type": "uint256"
                    }
               ],
               "stateMutability": "view",
               "type": "function"
          },
          {
               "inputs": [],
               "name": "OWNER",
               "outputs": [
                    {
                         "internalType": "address",
                         "name": "",
                         "type": "address"
                    }
               ],
               "stateMutability": "view",
               "type": "function"
          },
          {
               "inputs": [],
               "name": "RATE",
               "outputs": [
                    {
                         "internalType": "uint256",
                         "name": "",
                         "type": "uint256"
                    }
               ],
               "stateMutability": "view",
               "type": "function"
          },
          {
               "inputs": [],
               "name": "remainingFund",
               "outputs": [
                    {
                         "internalType": "uint256",
                         "name": "",
                         "type": "uint256"
                    }
               ],
               "stateMutability": "view",
               "type": "function"
          }
     ];
     const provider = new ethers.providers.Web3Provider(window.ethereum);
     const signer = provider.getSigner();
     contract = new ethers.Contract(Address, Abi, signer);
};
export default connectContract;
export { contract };
